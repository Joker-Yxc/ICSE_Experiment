# Overleaf upload

Upload this entire folder while preserving the `figures/` subfolder, then set
`main.tex` as the Overleaf Main document.

The evaluation fragment searches for each figure in:

1. `figures/`
2. `docs/figures/`
3. the same folder as the Main document

PDF is preferred for publication-quality vector output; PNG is included only
as a fallback. If the figures still appear as empty boxes, check that
`graphicx` is not loaded with the `draft` option and that the project compiler
is pdfLaTeX, XeLaTeX, or LuaLaTeX.

To use the fragment in an existing paper, copy
`evaluation_icse2027.tex` and the `figures/` folder into the project and add:

```tex
\input{evaluation_icse2027}
```

The complete leakage-safe baseline table is in
`evaluation_icse2027_appendix.tex`.
